web project 10
Michael Scharff

we now have a lot of functional components such as Card, Section, Popup and more.
the project is a page of social media. you can see a picture of some very beutiful views and you can like them. you can edit the profile name and about me and can add a post. you can now exit any popup by clicking the "ESC" button or just clicking with your mouse on the popup overlay. i used the grid technique with the cards and flex with everything else.

the project is now on react and not HTML.

https://github.com/Minka1902/around-react.git
https://minka1902.github.io/around-react/  